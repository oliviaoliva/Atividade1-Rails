class Contact < ApplicationRecord
  belongs_to :store
end
