class Manager < ApplicationRecord
  belongs_to :store
end
